#!/usr/bin/env bash
# 把《命运 2》军械库编译成 .jar（Linux / macOS）
# 前提：JDK 21 + Gradle ≥ 8.8 + 首次构建时能联网
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v java >/dev/null 2>&1; then
  echo "[失败] 没有找到 java。请安装 JDK 21：https://adoptium.net/"
  exit 1
fi

major=$(java -version 2>&1 | awk -F'"' '/version/ {print $2}' | cut -d. -f1)
echo "JDK 主版本：$major"
if [ "${major:-0}" -lt 21 ]; then
  echo "[失败] 需要 JDK 21+，当前 $major"
  exit 1
fi

if command -v gradle >/dev/null 2>&1; then
  GRADLE=gradle
elif [ -x ./gradlew ]; then
  GRADLE=./gradlew
else
  echo "[失败] 没有找到 Gradle。装一个 8.10，或先执行：gradle wrapper --gradle-version 8.10"
  exit 1
fi

echo "开始构建（首次会下载 Minecraft / NeoForge 依赖，需要几分钟）..."
$GRADLE build --no-daemon

echo
echo "mod jar："
ls -lh build/libs/*.jar | grep -v -E 'sources|dev' || true

if command -v python3 >/dev/null 2>&1; then
  echo
  echo "顺便生成 TaCZ 枪包..."
  python3 tools/package_pack.py
fi

echo
echo "完成。mod jar 放 mods/；枪包（dist/*.jar 或 *.zip）放 tacz/。"
