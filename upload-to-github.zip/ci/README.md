# 用 CI 产出 jar（不需要本机装 JDK/Gradle）

CI 用的是 GitHub Actions，构建环境自带 JDK 17 + Gradle 8.8，
产物是 `destiny2-arsenal-1.2.0.jar`（Forge 1.20.1），可直接丢进 `mods/`。

> 你本机没有 git（我确认过），所以下面给的是**网页操作**路线，不需要命令行。

---

## 最快路径：只上传「1 个 zip + 1 个工作流」（2 步）

GitHub 网页上传**一次最多 100 个文件**，本工程有 140+ 个，拖拽会直接报
*“Yowza, that's a lot of files.”* ——所以改成让 CI 自己解压。

### 步骤一：上传单个压缩包

1. 打开 <https://github.com/new> 建仓库（Private 也行）→ Create；
2. 仓库里 **Add file → Upload files** → 上传 **`dist/upload-to-github.zip`**（就这一个文件）；
3. **Commit changes**。

### 步骤二：创建引导工作流

1. **Add file → Create new file**；
2. 文件名输入：
   ```
   .github/workflows/bootstrap-build.yml
   ```
3. 把 **`ci/bootstrap-build.yml`** 的全部内容粘贴进去；
4. **Commit changes** —— 这一步提交会立刻触发 CI。

它会自动完成：解压 zip → 把工程提交回仓库 → JDK 17/Gradle 8.8 → 跑自测 → 编译 jar → 上传产物。

### 步骤三：下载 jar

1. 仓库顶部 **Actions** → 最新一次 `bootstrap-and-build`（首次约 5–10 分钟）；
2. 等绿 → 页面底部 **Artifacts** → 下载 `destiny2-arsenal-forge-1.20.1.zip`；
3. 解压取出 `destiny2-arsenal-1.2.0.jar` → 丢进 `逆转未来2.3.3\mods\`。

---

## 备选：坚持手动上传工程

如果不想用引导工作流，就得把文件分两批上传（每批 < 100）：

- **第一批**：`src/`、`build.gradle`、`settings.gradle`、`gradle.properties`、`ci/`、`tools/`
- **第二批**：`tacz_pack/`、`docs/`、`README.md`、`LICENSE` 等根文件
- 然后再按下面的「步骤三」单独创建 `.github/workflows/build.yml`

> 注意：网页拖拽上传会**跳过 `.github` 这类点目录**，所以工作流永远要用
> 「Create new file + 粘贴」的方式建。

---

## 旧版分步说明（保留作参考）

## 步骤一：建仓库

1. 打开 <https://github.com/new>
2. 填名字，比如 `destiny2-arsenal`，选 **Private**（公开也行），
   勾不勾 `Add a README file` 都无所谓 → **Create repository**

## 步骤二：上传工程

1. 解压 `destiny2-arsenal-1.2.0-forge-src.zip`；
2. 在仓库页面点 **Add file → Upload files**；
3. 把解压后的**所有内容**拖进去（`src`、`tacz_pack`、`tools`、`build.gradle` …），
   → **Commit changes**。

> ⚠️ 网页拖拽上传**会忽略 `.github` 这种点开头的目录**，所以工作流文件要单独建（步骤三）。

## 步骤三：创建 CI 工作流（关键一步）

1. 在仓库点 **Add file → Create new file**；
2. 文件名输入（可直接输入完整路径）：
   ```
   .github/workflows/build.yml
   ```
3. 把仓库里 `ci/build.yml`（与本文件同级的那个副本）的**全部内容**粘贴进去；
4. **Commit changes**。

推上去的同时 Actions 就会自动开始跑。

## 步骤四：下载 jar

1. 仓库页顶部 **Actions** 标签 → 点最新那次 `build-forge-1.20.1`；
2. 等它变绿（首次约 5–10 分钟，要下载 Minecraft/Forge 依赖）；
3. 页面底部 **Artifacts** → 下载 `destiny2-arsenal-forge-1.20.1.zip`；
4. 解压，里面是：
   - `destiny2-arsenal-1.2.0.jar` ← **丢进 `mods/`**
   - `d2arsenal_gun_pack.zip` ← 已被 jar 内嵌，不用手动放（想手动覆盖也行）

## 步骤五：进游戏

1. 把 jar 放进 `逆转未来2.3.3\mods\`；
2. 启动，日志里应有：
   ```
   [命运 2 军械库] 已装填 8 把异域武器。
   已释放 TaCZ 枪包：...\逆转未来2.3.3\tacz\d2arsenal_gun_pack.zip
   ```
   （第二行只在 `tacz/` 里还没有该枪包时出现；我之前已经手动装过一份，所以你会看到「跳过释放」）
3. 创造模式物品栏出现 **「天命军械库」** 页签；TaCZ 的枪械工作台里出现 **Destiny 2 Arsenal** 枪包。

---

## 如果 CI 红了

| 报错关键词 | 原因 | 处理 |
| --- | --- | --- |
| `Plugin [id: 'net.minecraftforge.gradle'] was not found` | 仓库里没有 `settings.gradle`，或没上传 `build.gradle` | 确认根目录有这两个文件 |
| `Could not resolve net.minecraftforge:forge:1.20.1-47.4.0` | Forge maven 暂时不可达 | 重跑一次（Actions 里有 **Re-run jobs**） |
| `Unsupported class file major version` | 有人在 `build.gradle` 里改了 toolchain | 保持 `languageVersion = 17` |
| `error: cannot find symbol ... appendHoverText` 之类 | 平台 API 与 1.20.1 不一致 | 把报错贴给我，我按 1.20.1 的真实签名改 |
| `validate.py` 那一步失败 | 工程/内嵌枪包结构被改动 | 看输出里列出的具体问题 |

把红色那次的**日志前 50 行 + 第一条 error** 发我即可，Forge 映射差异我能直接修。
