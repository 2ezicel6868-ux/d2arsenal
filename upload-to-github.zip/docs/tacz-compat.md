# 与 TaCZ（Timeless and Classics Zero）的兼容说明

## 一、先说硬约束

TaCZ 的平台支持矩阵（官方 readme）：

| Minecraft | 加载器 | 状态 |
| --- | --- | --- |
| 1.18.2 / 1.19.2 | Forge | 已停止支持 |
| **1.20.1** | **Forge** | 长期支持（1.x） |
| **1.21.1** | **NeoForge** | 长期支持（1.x，最新 1.2.0，需要 Java 21） |

**TaCZ 没有 Fabric 版本。** 而 Fabric 与 NeoForge 的 mod 不能装进同一个实例，
所以「和 TaCZ 一起玩」这件事，等价于「本 mod 必须是 NeoForge 1.21.1 版本」。
本工程已按此移植（详见 README 第五节的版本表）。

---

## 二、共存是怎么做到的

本 mod 与 TaCZ 在以下 8 个维度上完全隔离，所以能同装：

| 维度 | TaCZ | 本 mod | 冲突风险 |
| --- | --- | --- | --- |
| 命名空间 | `tacz:` | `destinyarsenal:` | 无 |
| 物品栏 | 自己的页签 | 自己的「天命军械库」页签 | 无 |
| 右键行为 | 只在手持 `tacz:` 的枪时接管 | 只在手持本 mod 的枪时接管 | 无（互相判断 `instanceof`） |
| 按键 | 有自己的换弹/开镜键 | **不注册任何按键** | 无 |
| 渲染 | 用 Mixin 替换手持枪械渲染 | 无 Mixin，走原版物品渲染 | 无（TaCZ 只对自家枪生效） |
| 物品数据 | `minecraft:custom_data` | 原版 `damage` 组件（当弹药条） | 无（互不写入） |
| 合成 | 自己的枪械配方 | 8 个原版 3×3 配方 | 无 |
| 枪包系统 | `tacz` 枪包（zip / 资源包） | 不用枪包 | 无 |

本 mod 在 `neoforge.mods.toml` 里声明了：

```toml
[[dependencies.destinyarsenal]]
    modId="tacz"
    type="optional"
    versionRange="*"
    ordering="AFTER"
    side="BOTH"
```

作用有三：明确加载顺序（本 mod 在 TaCZ 之后初始化）、让启动日志里两个 mod 都被识别、
以及**不装 TaCZ 也不影响本 mod 运行**（`optional` 不会强校验）。

> 如果 TaCZ 的实际 modId 不是 `tacz`（例如某些分支改了 id），NeoForge 只会忽略这条可选依赖，
> 不影响任何功能，改一下这行即可。

---

## 三、验证到哪一步了

| 项目 | 状态 |
| --- | --- |
| 命名空间 / 注册名不冲突 | ✅ 静态核对（`destinyarsenal` vs `tacz`） |
| 不注册全局按键 | ✅ 代码里没有任何 key mapping 注册 |
| 无 Mixin、无自定义实体/网络包 | ✅ 代码审查（全工程 0 个 `.json` mixin 配置、0 个 `Entity` 子类） |
| 数据组件互不覆盖 | ✅ 本 mod 只读写 `damage`，TaCZ 用 `custom_data` |
| **真实同时加载测试** | ⚠️ **未做**：构建与进游戏测试需要 JDK 21 + 联网，本机不具备 |

也就是说：共存方案在**设计层面**是干净的，但真正「两个 jar 一起启动不崩」还需要你在正式实例里点一次。
出问题时的排查顺序见第五节。

---

## 四、如果要做「数据互通」

目前**不互通**：两边各用各的弹药逻辑，TaCZ 的配件装不上本 mod 的枪，本 mod 的特性也挂不到 TaCZ 的枪上。
真要互通，有三条路，代价差别很大：

### 路线 A：把 8 把枪做成 TaCZ 枪包（推荐给「想要 3D 模型和动画」的人）

- **得到**：TaCZ 的 3D 模型、换弹/开镜动画、后坐力曲线、配件槽、枪械音效、弹药系统；
- **失去**：狼群弹、亡命叠层、黑洞这类**复杂特性**在纯数据层做不出来，只能保留「伤害/射速/弹匣/后坐力」这些字段；
- **代价**：需要自己建模 + 写 `tacz` 枪包 JSON（`guns/index`、`guns/data`、`animations`、`models`、`textures`），
  工作量主要在**美术**，几乎不需要 Java；
- **注意**：TaCZ 1.21.1 的枪包要和 1.20.1 通用主包区分（用版本覆盖层），或用 `/tacz convert universal` 转换旧包。

### 路线 B：写一个依赖 TaCZ 的 NeoForge addon

- **得到**：可以让 TaCZ 的枪触发本 mod 的某些逻辑，或让本 mod 的枪走 TaCZ 的开火管线；
- **前提**：TaCZ 必须提供稳定的 Java API；
- **现实**：TaCZ 在 1.21.1 的 1.2.0 里**明确写了「暂不提供 KubeJS 专用兼容接口」**，
  而 Java 侧并没有对外承诺的稳定 API。这条路等于贴着 TaCZ 内部实现写，版本一升级就容易碎；
- **建议**：除非你愿意每次跟着 TaCZ 升级改代码，否则不要走。

### 路线 C：共享弹药（读写 TaCZ 的 `custom_data`）

- 理论上可以把本 mod 的换弹改成消耗 `tacz:` 的弹药物品（`ItemStack.is(taCZ弹药物品)`），
  这样「弹药互通」是最省事的，不需要碰 TaCZ 的内部数据结构；
- **但**需要知道 TaCZ 各弹药物品的注册名，而且它属于 TaCZ 的内部约定，可能变；
- 这是三条路里「收益/风险」比最好的一条，适合以后再加。

**当前建议**：先保持两套独立体系（干净、稳定），想要模型和动画就走路线 A 单独做枪包。

---

## 五、同装后出问题的排查顺序

1. **看是哪个 mod 崩的**：`logs/latest.log` 里搜 `destinyarsenal` 与 `tacz`，
   先确认崩在 `Mod loading`（依赖/版本问题）还是 `Game loading`（注册表冲突）。
2. **报「Missing or unsupported mandatory dependency」**：NeoForge 版本低于 21.1.0。
   本 mod 要求 `[21.1.0,)`，TaCZ 1.2.0 也要求 21.1.x —— 把 NeoForge 升到 21.1.215。
3. **进游戏后右键没反应**：确认手持的是本 mod 的枪（`destinyarsenal:` 前缀），
   而不是 TaCZ 的枪——两套枪械的操作是分开实现的。
4. **两个 mod 的物品栏页签互相盖住**：这是创造模式页签顺序问题，不影响功能；
   TaCZ 页签里不会出现本 mod 的枪。
5. **怀疑渲染冲突**：本 mod 没有任何 Mixin，不会与 TaCZ 的渲染注入点竞争；
   如果出现手持模型异常，先排查其它 mod 或资源包。
6. **确认两个 mod 都加载了**：`/neoforge mods list`（或日志里的 mod 列表）应同时出现
   `tacz` 与 `destinyarsenal`。

---

## 六、版本建议

| 组件 | 建议版本 | 说明 |
| --- | --- | --- |
| Minecraft | 1.21.1 | 两个 mod 共同支持 |
| NeoForge | **21.1.215** | TaCZ 1.2.0 要求 21.1.x；本 mod 要求 ≥ 21.1.0 |
| TaCZ | 1.2.0（NeoForge 1.21.1） | 1.1.x 也能跑，但 1.2.0 之后的枪包/数据组件适配更完整 |
| JDK（仅开发） | 21 | 1.21.1 的字节码版本 |
