# 验证记录

本仓库是在**没有外网、没有 Gradle、只有 JDK 25** 的机器上完成的，因此无法在这里产出 `.jar`。
为了尽可能把「第一次构建就成功」的概率拉满，下面这些检查是**真的执行过**的，命令可复现。

## 已执行并通过

| # | 检查 | 命令 | 结果 |
| --- | --- | --- | --- |
| 1 | 纯 Java 核心编译（不依赖 MC） | `javac --release 21 -d out core/*.java` | 10 个文件，0 错误 |
| 2 | 核心逻辑自测：射线求交 / 散布 / 伤害衰减 / 特性倍率 / 换弹状态机 / 武器表 | `java -cp out dev.destinyarsenal.core.CoreSelfTest` | **70 / 70 通过** |
| 3 | 全量 Java 语法扫描（编译意图 + 过滤掉「缺少 MC/NeoForge 包」的预期错误） | `javac -Xmaxerrs 100000 src/main/java` | 非预期错误 **0** |
| 4 | 未解析符号审计（把 javac 报的 `cannot find symbol` 去重） | 同上输出后处理 | 40 个符号，**全部**是 `net.minecraft.*` / `net.neoforged.*` 类型；**没有任何一个**是本工程自己的成员 |
| 5 | 资源与工程一致性校验 | `python tools/validate.py` | **238 项全部通过**（新增：内嵌枪包结构、Forge/NeoForge 残留检查） |
| 6 | TaCZ 枪包一致性校验 | `python tools/validate_tacz_pack.py` | **358 项全部通过**（8 把枪 / 4 种弹药） |
| 7 | 枪包模型肉眼检查 | `python tools/preview_models.py` → 等距投影图 | 修掉 3 处悬空/断开的方块；定位组枢纽点位置可视核对 |
| 8 | 枪包发行包（zip/jar）结构 | `python tools/package_pack.py` | 各 74 条目，`gunpack.meta.json` 在根目录，`.jar` 与 `.zip` **字节完全相同** |
| 9 | `build.ps1` 冒烟测试 | `powershell -ExecutionPolicy Bypass -File build.ps1 -PackOnly` | exit=0，正常产出 dist 下两个文件 |

第 4 项的意义：语法扫描会把「找不到 Minecraft 类」这类错误过滤掉，但**自己写错的成员名**
同样会表现为 `cannot find symbol`。所以额外把那 40 个未解析符号逐个看了一遍——
只有当它们全部属于 MC/NeoForge 时，才能说明本工程的内部一致性是好的。
这一轮正是靠它抓到了移植时的真 bug（见下）。

第 5 项具体校验了：

- 所有 JSON 可解析；
- `META-INF/neoforge.mods.toml` 可被 TOML 解析，`modLoader` 为 `javafml`，
  `[[mods]]` 的 `modId` / 版本与 `gradle.properties` 一致，`logoFile` 真实存在，
  依赖里声明了 `neoforge` / `minecraft` / **`tacz`（optional）**；
- **没有任何 Fabric 残留**（无 `fabric.mod.json`、无 `net.fabricmc` 导入、build.gradle 无 fabric 插件）；
- **`core` 包保持纯 Java**（不 import Minecraft）；
- `WeaponCatalog.java` 解析出恰好 8 把枪，每把都有：模型、16×16 贴图、3×3 配方、中英文名称；
- 模型 `layer0` 与贴图名一一对应；icon 尺寸 128×128；
- `en_us` 与 `zh_cn` 键集合完全相等（集合相等，不是「大概一致」）；
- Java 里每个 `Component.translatable("...")` 的字面量键，在两个语言文件里都存在；
- 枚举里定义的武器类型 / 元素 / 特性 key 都有语言条目；
- 配方排版 3×3、图案符号都有材料、产物 id 与注册名一致；
- `ModItems` 注册的 8 个 `DeferredItem` 与武器表完全对应、无重复。

## 移植过程中真实抓到的两个 bug

这两个都是「不编译就发现不了」的，值得记下来：

1. **`Fx.java` 重复导入同名类**
   `import dev.destinyarsenal.core.Vec3;` 与 `import net.minecraft.world.phys.Vec3;` 同时存在，
   javac 报 24 处 `x has private access in Vec3`（把 Minecraft 的 `Vec3` 解析成了 core 里那个 record）。
   修法：删掉 core 的导入，Minecraft 侧一律写全限定名（`McVec` 就是这么做的）。
2. **`def.range()` 写成了方法调用**
   `WeaponDef.range` 是 public final **字段**，不是方法。javac 只报一句
   `cannot find symbol: method range()`，混在几百条「找不到 MC 包」里很容易被过滤掉。
   修法：改成 `def.range`。

## 尚未执行（需要你的环境）

| 检查 | 为什么没做 | 怎么做 |
| --- | --- | --- |
| `gradle build` 产出 jar | 本机无 Gradle、无外网、只有 JDK 25（ForgeGradle 6 需要 JDK 17） | **用 CI**（见 `ci/README.md`），或本机装 JDK 17 后 `build.ps1` |
| `gradle runClient` 进游戏实测 | 同上，且需要下载 Forge 47.4.x | IDEA 里跑 `runClient` |
| **与 TaCZ 真实同装** | 需要两个 jar 同时进正式实例 | 见 `docs/tacz-compat.md` 第三节 |
| TaCZ 枪包实际加载 | 需要 TaCZ 运行环境 | 见 `docs/tacz-pack.md` 第七节 |

## 首次构建要盯的三处

按风险从高到低，如果编译报错，先看这里（都是「改一行」级别）：

1. `item/GunItem.java#appendHoverText` 的四个参数
   —— 1.21.1 是 `(ItemStack, Item.TooltipContext, List<Component>, TooltipFlag)`。
2. `combat/Guns.java` / `combat/Explosions.java` 里的 `setDeltaMovement(x, y, z)` 与 `hasImpulse`
   —— 老版本可能只接受 `Vec3` 重载。
3. `combat/Fx.java` 的 `ParticleTypes.SNOWFLAKE`（只给 `ElementKind.STASIS` 用，当前 8 把枪都没用到）
   —— 若该常量不存在，删掉那一行 `case STASIS` 即可。

其余用到的 API（`InteractionResultHolder`、`DeferredRegister.Items`、`CreativeModeTab.builder()`、
`Item#getUseDuration/releaseUsing`、`level.clip(ClipContext)`、`LivingEntity#hurt`、
`ServerLevel#sendParticles`、`ServerTickEvent.Post`）都按 1.21.1 的 Mojang 官方名书写，
并在 `docs/architecture.md` 的移植对照表里逐条列出。

## 自测覆盖清单

`src/test/java/dev/destinyarsenal/core/CoreSelfTest.java` 共 70 条断言：

- **武器表**：8 把、id 唯一、数值合法性（弹匣/换弹/射速/伤害/射程/散布关系）、蓄力机制边界、`roundsLeft`
- **射线 / 包围盒**：正面命中距离、侧向打空、平行且在盒外、平行且穿过、`stretch` / `expand`
- **散布**：潜行 < 静止 < 滞空 < 冲刺、零散布不改方向、偏移角不超设定值、单位向量、同种子可复现
- **弹道学**：射程内满伤、超程衰减且有下限、爆头高度比、爆炸中心/边缘、环形偏移半径、后坐力（滞空更小）
- **特性**：亡命每层 +6% 与 5 层封顶、其他特性无加成、雷神 3 连击触发、萤火需「精准 + 击杀」、奇点仅需击杀、蓄力 3.5×
- **状态机**：开火冷却、换弹期间禁射、重复换弹被拒、换弹计时、换弹后强化一发、开火消耗强化、叠层封顶、换弹清层、换枪不影响冷却、蓄力计时归零
