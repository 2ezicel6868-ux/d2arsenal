package dev.destinyarsenal.combat;

import dev.destinyarsenal.DestinyArsenal;
import net.minecraft.server.MinecraftServer;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * 极简的「服务器 tick 延迟任务」队列。
 * <p>狼群弹、灼烧、虚空奇点这些都靠它实现，避免为了几帧延迟就引入自定义实体。</p>
 */
public final class Scheduler {

    private record Task(int dueTick, Runnable action) {
    }

    private static final List<Task> TASKS = new ArrayList<>();

    private Scheduler() {
    }

    /** 按服务器 tick 计数延迟执行（单位 tick，20 tick = 1 秒）。 */
    public static void schedule(MinecraftServer server, int delayTicks, Runnable action) {
        TASKS.add(new Task(server.getTickCount() + Math.max(0, delayTicks), action));
    }

    public static void tick(MinecraftServer server) {
        if (TASKS.isEmpty()) {
            return;
        }
        int now = server.getTickCount();
        Iterator<Task> iterator = TASKS.iterator();
        while (iterator.hasNext()) {
            Task task = iterator.next();
            if (now < task.dueTick()) {
                continue;
            }
            iterator.remove();
            try {
                task.action().run();
            } catch (RuntimeException exception) {
                DestinyArsenal.LOGGER.error("延迟任务执行失败", exception);
            }
        }
    }

    /** 服务器停止时清空，避免下次开服残留任务立刻触发。 */
    public static void clear() {
        TASKS.clear();
    }
}
