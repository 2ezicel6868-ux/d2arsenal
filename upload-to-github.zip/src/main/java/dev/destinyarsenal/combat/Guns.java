package dev.destinyarsenal.combat;

import dev.destinyarsenal.core.Ballistics;
import dev.destinyarsenal.core.ElementKind;
import dev.destinyarsenal.core.GunRuntime;
import dev.destinyarsenal.core.PerkEngine;
import dev.destinyarsenal.core.Spread;
import dev.destinyarsenal.core.Vec3;
import dev.destinyarsenal.core.WeaponDef;
import dev.destinyarsenal.item.GunItem;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;

import java.util.List;
import java.util.Random;

/**
 * 开火与命中结算，以及每把枪的独有特性。
 * <p>一把枪 = 一个 {@code perk} 分支，数值全部来自 {@link WeaponDef}。</p>
 */
public final class Guns {

    private static final Random RANDOM = new Random();

    private Guns() {
    }

    /** 开一枪（或一次蓄力射击）。 */
    public static void fire(ServerLevel level, Player player, ItemStack stack, GunItem gun,
                            GunRuntime runtime, boolean empowered) {
        WeaponDef def = gun.def();
        MinecraftServer server = level.getServer();
        long now = server.getTickCount();

        int rounds = def.roundsLeft(stack.getDamageValue());
        if (rounds <= 0) {
            return;
        }

        boolean wasPrimed = runtime.isPrimed();
        boolean useEmpowered = empowered && rounds > def.empoweredCost;
        int cost = useEmpowered ? 1 + def.empoweredCost : 1;
        stack.setDamageValue(stack.getDamageValue() + Math.min(cost, rounds));
        runtime.markShot(now);

        Vec3 look = McVec.toCore(player.getViewVector(1.0F));
        double spread = Spread.effectiveSpread(def, player.isSprinting(), !player.onGround(), player.isShiftKeyDown());
        Vec3 direction = Spread.jitter(look, spread, RANDOM);

        Fx.shoot(level, player, def);
        Fx.muzzle(level, player, def.element);

        Hitscan.Hit hit = Hitscan.trace(level, player, direction, def.range);

        float damage = PerkEngine.empoweredDamage(def, useEmpowered)
                * PerkEngine.damageMultiplier(def.perk, runtime.stacks());
        if (wasPrimed) {
            // 旭日：换弹后的第一枪强化
            damage *= 1.25F;
        }

        resolve(level, player, def, runtime, hit, damage, useEmpowered);
        recoil(player, def);
    }

    private static void resolve(ServerLevel level, Player player, WeaponDef def, GunRuntime runtime,
                                Hitscan.Hit hit, float baseDamage, boolean empowered) {
        LivingEntity target = hit.target();
        Vec3 impact = McVec.toCore(hit.position());

        if (target != null) {
            float damage = baseDamage * (hit.critical() ? def.critMultiplier : 1.0F);
            damage = Ballistics.damageAtDistance(damage, hit.distance(), def.range);
            boolean lethal = target.getHealth() <= damage;

            target.hurt(level.damageSources().playerAttack(player), damage);
            Fx.hit(level, hit.position(), def.element, hit.critical());

            switch (def.perk) {
                case "wolfpack" -> wolfpack(level, player, impact);
                case "desperado" -> runtime.addStack(PerkEngine.DESPERADO_MAX_STACKS);
                case "lightning_rounds" -> {
                    int streak = runtime.addStack(PerkEngine.THUNDER_HITS_REQUIRED);
                    if (PerkEngine.shouldTriggerThunder(def.perk, streak)) {
                        runtime.resetStacks();
                        thunder(level, player, impact);
                    }
                }
                case "sunblast" -> {
                    Explosions.damageArea(level, player, impact, 1.8D, 4.0F, ElementKind.SOLAR);
                    sunburn(level, player, target);
                }
                case "firefly" -> {
                    if (PerkEngine.triggersFirefly(def.perk, hit.critical(), lethal)) {
                        firefly(level, player, impact);
                    }
                }
                case "black_hole" -> {
                    if (PerkEngine.triggersSingularity(def.perk, lethal)) {
                        singularity(level, player, impact);
                    }
                }
                case "micro_missile" -> {
                    Explosions.damageArea(level, player, impact, 5.0D, 14.0F, ElementKind.KINETIC);
                    selfLaunch(level, player, impact, 1.0D);
                }
                default -> {
                }
            }

            if (empowered) {
                Fx.empowered(level, player);
            }
            return;
        }

        // 没打中实体：只有真的撞到方块才炸，飞空了什么都不做
        if (!hit.blocked()) {
            return;
        }
        Fx.impact(level, hit.position(), def.element);
        switch (def.perk) {
            case "wolfpack" -> wolfpack(level, player, impact);
            case "micro_missile" -> {
                Explosions.damageArea(level, player, impact, 5.0D, 14.0F, ElementKind.KINETIC);
                selfLaunch(level, player, impact, 1.0D);
            }
            case "sunblast" -> Explosions.damageArea(level, player, impact, 1.6D, 3.0F, ElementKind.SOLAR);
            default -> {
            }
        }
    }

    /** 狼嚎：命中后撒出 6 枚延迟爆炸的「狼群弹」。 */
    private static void wolfpack(ServerLevel level, Player owner, Vec3 center) {
        MinecraftServer server = level.getServer();
        for (int i = 0; i < PerkEngine.WOLFPACK_ROUNDS; i++) {
            Vec3 point = Ballistics.ringOffset(center, 1.4D + 0.4D * i, i, PerkEngine.WOLFPACK_ROUNDS);
            Scheduler.schedule(server, 3 + i,
                    () -> Explosions.damageArea(level, owner, point, 2.6D, 5.0F, ElementKind.SOLAR));
        }
        Fx.playAt(level, McVec.toMc(center), SoundEvents.FIREWORK_ROCKET_BLAST, 1.2F, 1.4F);
    }

    /** 雷神：第三次连续命中引发雷暴。 */
    private static void thunder(ServerLevel level, Player owner, Vec3 center) {
        Explosions.damageArea(level, owner, center, 3.6D, 11.0F, ElementKind.ARC);
        level.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                center.x(), center.y(), center.z(), 60, 1.2D, 1.2D, 1.2D, 0.6D);
        Fx.playAt(level, McVec.toMc(center), SoundEvents.LIGHTNING_BOLT_THUNDER, 1.0F, 1.3F);
    }

    /** 命运终结者：精准击杀引爆萤火。 */
    private static void firefly(ServerLevel level, Player owner, Vec3 center) {
        Explosions.damageArea(level, owner, center, 3.4D, 10.0F, ElementKind.KINETIC);
        level.sendParticles(ParticleTypes.CRIT,
                center.x(), center.y(), center.z(), 40, 1.0D, 1.0D, 1.0D, 0.4D);
        Fx.playAt(level, McVec.toMc(center), SoundEvents.GENERIC_EXPLODE, 0.9F, 1.6F);
    }

    /** 旭日：灼烧 4 秒。 */
    private static void sunburn(ServerLevel level, Player owner, LivingEntity target) {
        MinecraftServer server = level.getServer();
        for (int i = 1; i <= PerkEngine.SUNBURN_TICKS; i++) {
            Scheduler.schedule(server, i * 8, () -> {
                if (target.isAlive()) {
                    target.hurt(level.damageSources().playerAttack(owner), 1.2F);
                    level.sendParticles(ParticleTypes.FLAME,
                            target.getX(), target.getY() + target.getBbHeight() * 0.5D, target.getZ(),
                            4, 0.25D, 0.35D, 0.25D, 0.01D);
                }
            });
        }
    }

    /** 引力子长矛：击杀留下虚空奇点，吸引并持续伤害敌人。 */
    private static void singularity(ServerLevel level, Player owner, Vec3 center) {
        MinecraftServer server = level.getServer();
        for (int step = 1; step <= 10; step++) {
            Scheduler.schedule(server, step * 4, () -> pull(level, owner, center));
        }
        Scheduler.schedule(server, 44,
                () -> Explosions.damageArea(level, owner, center, 5.0D, 9.0F, ElementKind.VOID));
        Fx.playAt(level, McVec.toMc(center), SoundEvents.ENDERMAN_TELEPORT, 1.0F, 0.6F);
    }

    private static void pull(ServerLevel level, Player owner, Vec3 center) {
        AABB area = new AABB(
                center.x() - 6.0D, center.y() - 6.0D, center.z() - 6.0D,
                center.x() + 6.0D, center.y() + 6.0D, center.z() + 6.0D);
        List<Entity> entities = level.getEntities(owner, area,
                entity -> entity instanceof LivingEntity && entity.isAlive());

        net.minecraft.world.phys.Vec3 centerVec = McVec.toMc(center);
        for (Entity entity : entities) {
            net.minecraft.world.phys.Vec3 toCenter = centerVec.subtract(entity.position());
            double lengthSqr = toCenter.lengthSqr();
            if (lengthSqr > 36.0D || lengthSqr < 0.01D) {
                continue;
            }
            net.minecraft.world.phys.Vec3 pull = toCenter.normalize().scale(0.28D);
            entity.setDeltaMovement(pull.x, 0.05D, pull.z);
            entity.hasImpulse = true;
            if (entity instanceof LivingEntity living && lengthSqr < 16.0D) {
                living.hurt(level.damageSources().playerAttack(owner), 0.8F);
            }
        }
        level.sendParticles(ParticleTypes.PORTAL,
                center.x(), center.y() + 1.0D, center.z(), 24, 2.0D, 2.0D, 2.0D, 0.4D);
    }

    /** 山巅：爆炸把自己往上顶，可以「火箭跳」。 */
    private static void selfLaunch(ServerLevel level, Player player, Vec3 center, double strength) {
        net.minecraft.world.phys.Vec3 position = player.position();
        double distance = position.distanceTo(McVec.toMc(center));
        if (distance > 5.0D) {
            return;
        }
        double factor = 1.0D - distance / 5.0D;
        net.minecraft.world.phys.Vec3 velocity = player.getDeltaMovement();
        player.setDeltaMovement(velocity.x, velocity.y + strength * (0.45D + 0.55D * factor), velocity.z);
        player.hasImpulse = true;
        player.displayClientMessage(Component.translatable("message.destinyarsenal.rocket_jump"), true);
    }

    /** 很轻的后坐力「顿挫」，重力会立刻吃掉它，只留下手感。 */
    private static void recoil(Player player, WeaponDef def) {
        Vec3 impulse = Ballistics.recoilImpulse(def, !player.onGround());
        net.minecraft.world.phys.Vec3 velocity = player.getDeltaMovement();
        player.setDeltaMovement(velocity.x, velocity.y + impulse.y(), velocity.z);
        player.hasImpulse = true;
    }
}
