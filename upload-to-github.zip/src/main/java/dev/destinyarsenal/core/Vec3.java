package dev.destinyarsenal.core;

/**
 * 与 Minecraft 无关的三维向量（纯 Java，可单元测试）。
 * <p>之所以不直接用 {@code net.minecraft.util.math.Vec3d}，是为了让整个
 * {@code core} 包可以在没有 Minecraft 依赖的情况下被 javac 编译并测试。</p>
 */
public record Vec3(double x, double y, double z) {

    public static final Vec3 ZERO = new Vec3(0.0D, 0.0D, 0.0D);
    public static final Vec3 UP = new Vec3(0.0D, 1.0D, 0.0D);

    public Vec3 add(Vec3 other) {
        return new Vec3(this.x + other.x, this.y + other.y, this.z + other.z);
    }

    public Vec3 add(double dx, double dy, double dz) {
        return new Vec3(this.x + dx, this.y + dy, this.z + dz);
    }

    public Vec3 subtract(Vec3 other) {
        return new Vec3(this.x - other.x, this.y - other.y, this.z - other.z);
    }

    public Vec3 subtract(double dx, double dy, double dz) {
        return new Vec3(this.x - dx, this.y - dy, this.z - dz);
    }

    public Vec3 scale(double factor) {
        return new Vec3(this.x * factor, this.y * factor, this.z * factor);
    }

    public double dot(Vec3 other) {
        return this.x * other.x + this.y * other.y + this.z * other.z;
    }

    public Vec3 cross(Vec3 other) {
        return new Vec3(
                this.y * other.z - this.z * other.y,
                this.z * other.x - this.x * other.z,
                this.x * other.y - this.y * other.x);
    }

    public double lengthSquared() {
        return this.x * this.x + this.y * this.y + this.z * this.z;
    }

    public double length() {
        return Math.sqrt(lengthSquared());
    }

    public double distanceTo(Vec3 other) {
        return subtract(other).length();
    }

    public Vec3 normalize() {
        double len = length();
        if (len < 1.0E-6D) {
            return ZERO;
        }
        return scale(1.0D / len);
    }

    public Vec3 lerp(Vec3 other, double t) {
        return new Vec3(
                this.x + (other.x - this.x) * t,
                this.y + (other.y - this.y) * t,
                this.z + (other.z - this.z) * t);
    }
}
