package dev.destinyarsenal.core;

/**
 * 单把武器的全部数值定义（不可变）。
 * <p>用 {@link Builder} 构造，避免一长串位置参数导致调错。</p>
 */
public final class WeaponDef {

    public final String id;
    public final WeaponType type;
    public final ElementKind element;
    /** 弹匣容量（同时作为物品的 maxDamage）。 */
    public final int magazine;
    /** 换弹耗时（tick）。 */
    public final int reloadTicks;
    /** 单发基础伤害（半个红心 = 1.0）。 */
    public final float damage;
    /** 两发之间的最小间隔（tick）。 */
    public final int fireIntervalTicks;
    /** 有效射程（格）。 */
    public final float range;
    /** 腰射散布（度）。 */
    public final float hipSpread;
    /** 潜行/静止时的散布（度）。 */
    public final float bracedSpread;
    /** 后坐力强度。 */
    public final float recoil;
    /** 精准命中（爆头）伤害倍率。 */
    public final float critMultiplier;
    /** 是否为蓄力武器（伊邪那岐的重担）。 */
    public final boolean chargeable;
    /** 蓄满所需的 tick 数。 */
    public final int chargeTicks;
    /** 蓄力一击额外消耗的子弹数。 */
    public final int empoweredCost;
    /** 蓄力一击的伤害倍率。 */
    public final float empoweredMultiplier;
    /** 主特性标识（用于语言文件与 {@code Guns} 里的分支）。 */
    public final String perk;

    private WeaponDef(Builder b) {
        this.id = b.id;
        this.type = b.type;
        this.element = b.element;
        this.magazine = b.magazine;
        this.reloadTicks = b.reloadTicks;
        this.damage = b.damage;
        this.fireIntervalTicks = b.fireIntervalTicks;
        this.range = b.range;
        this.hipSpread = b.hipSpread;
        this.bracedSpread = b.bracedSpread;
        this.recoil = b.recoil;
        this.critMultiplier = b.critMultiplier;
        this.chargeable = b.chargeable;
        this.chargeTicks = b.chargeTicks;
        this.empoweredCost = b.empoweredCost;
        this.empoweredMultiplier = b.empoweredMultiplier;
        this.perk = b.perk;
    }

    public String nameKey() {
        return "item.destinyarsenal." + this.id;
    }

    public String perkNameKey() {
        return "weapon.destinyarsenal.perk." + this.perk + ".name";
    }

    public String perkDescKey() {
        return "weapon.destinyarsenal.perk." + this.perk + ".desc";
    }

    /** 剩余子弹数；{@code damage} 就是已消耗的子弹数。 */
    public int roundsLeft(int damage) {
        return Math.max(0, this.magazine - damage);
    }

    /** 每秒发射次数（用于文档与手感调试）。 */
    public double roundsPerSecond() {
        return 20.0D / this.fireIntervalTicks;
    }

    public static Builder builder(String id, WeaponType type, ElementKind element) {
        return new Builder(id, type, element);
    }

    /** 链式构造器。 */
    public static final class Builder {
        private final String id;
        private final WeaponType type;
        private final ElementKind element;
        private int magazine = 10;
        private int reloadTicks = 40;
        private float damage = 8.0F;
        private int fireIntervalTicks = 8;
        private float range = 32.0F;
        private float hipSpread = 1.6F;
        private float bracedSpread = 0.25F;
        private float recoil = 0.12F;
        private float critMultiplier = 1.5F;
        private boolean chargeable = false;
        private int chargeTicks = 0;
        private int empoweredCost = 0;
        private float empoweredMultiplier = 1.0F;
        private String perk = "none";

        private Builder(String id, WeaponType type, ElementKind element) {
            this.id = id;
            this.type = type;
            this.element = element;
        }

        public Builder magazine(int value) {
            this.magazine = value;
            return this;
        }

        public Builder reloadTicks(int value) {
            this.reloadTicks = value;
            return this;
        }

        public Builder damage(float value) {
            this.damage = value;
            return this;
        }

        public Builder fireIntervalTicks(int value) {
            this.fireIntervalTicks = value;
            return this;
        }

        public Builder range(float value) {
            this.range = value;
            return this;
        }

        public Builder spread(float hip, float braced) {
            this.hipSpread = hip;
            this.bracedSpread = braced;
            return this;
        }

        public Builder recoil(float value) {
            this.recoil = value;
            return this;
        }

        public Builder critMultiplier(float value) {
            this.critMultiplier = value;
            return this;
        }

        public Builder chargeable(int chargeTicks, int empoweredCost, float empoweredMultiplier) {
            this.chargeable = true;
            this.chargeTicks = chargeTicks;
            this.empoweredCost = empoweredCost;
            this.empoweredMultiplier = empoweredMultiplier;
            return this;
        }

        public Builder perk(String perk) {
            this.perk = perk;
            return this;
        }

        public WeaponDef build() {
            if (this.magazine < 1) {
                throw new IllegalStateException("弹匣容量必须 >= 1: " + this.id);
            }
            if (this.fireIntervalTicks < 1) {
                throw new IllegalStateException("射速间隔必须 >= 1: " + this.id);
            }
            return new WeaponDef(this);
        }
    }
}
