package dev.destinyarsenal.core;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * 8 把异域武器的数值表。
 * <p>所有数值集中在这里，改平衡只需要动这一个文件。</p>
 */
public final class WeaponCatalog {

    public static final String GJALLARHORN = "gjallarhorn";
    public static final String LAST_WORD = "last_word";
    public static final String FATEBRINGER = "fatebringer";
    public static final String THUNDERLORD = "thunderlord";
    public static final String SUNSHOT = "sunshot";
    public static final String IZANAGI = "izanagis_burden";
    public static final String MOUNTAINTOP = "mountaintop";
    public static final String GRAVITON_LANCE = "graviton_lance";

    private static final Map<String, WeaponDef> BY_ID = new LinkedHashMap<>();
    public static final List<WeaponDef> ALL;

    static {
        // 1. 狼嚎：弹匣只有 1 发，命中后撒出 6 枚追踪狼群弹。
        register(WeaponDef.builder(GJALLARHORN, WeaponType.ROCKET_LAUNCHER, ElementKind.SOLAR)
                .magazine(1)
                .reloadTicks(70)
                .damage(24.0F)
                .fireIntervalTicks(30)
                .range(48.0F)
                .spread(0.6F, 0.15F)
                .recoil(0.30F)
                .critMultiplier(1.2F)
                .perk("wolfpack")
                .build());

        // 2. 最后的话语：腰射全自动，命中叠「亡命」层数。
        register(WeaponDef.builder(LAST_WORD, WeaponType.HAND_CANNON, ElementKind.KINETIC)
                .magazine(8)
                .reloadTicks(40)
                .damage(7.0F)
                .fireIntervalTicks(4)
                .range(28.0F)
                .spread(2.2F, 0.55F)
                .recoil(0.16F)
                .critMultiplier(1.35F)
                .perk("desperado")
                .build());

        // 3. 命运终结者：精准击杀触发萤火爆炸。
        register(WeaponDef.builder(FATEBRINGER, WeaponType.HAND_CANNON, ElementKind.KINETIC)
                .magazine(12)
                .reloadTicks(36)
                .damage(9.0F)
                .fireIntervalTicks(8)
                .range(30.0F)
                .spread(1.1F, 0.20F)
                .recoil(0.14F)
                .critMultiplier(1.6F)
                .perk("firefly")
                .build());

        // 4. 雷神：连续 3 次命中触发雷暴。
        register(WeaponDef.builder(THUNDERLORD, WeaponType.MACHINE_GUN, ElementKind.ARC)
                .magazine(60)
                .reloadTicks(60)
                .damage(5.0F)
                .fireIntervalTicks(4)
                .range(34.0F)
                .spread(1.8F, 0.5F)
                .recoil(0.10F)
                .critMultiplier(1.3F)
                .perk("lightning_rounds")
                .build());

        // 5. 旭日：每发命中都带小爆炸 + 灼烧，换弹后首发强化。
        register(WeaponDef.builder(SUNSHOT, WeaponType.HAND_CANNON, ElementKind.SOLAR)
                .magazine(8)
                .reloadTicks(34)
                .damage(8.0F)
                .fireIntervalTicks(7)
                .range(26.0F)
                .spread(1.3F, 0.30F)
                .recoil(0.15F)
                .critMultiplier(1.5F)
                .perk("sunblast")
                .build());

        // 6. 伊邪那岐的重担：蓄满后一发「荣耀之弹」打出 4 发弹药的伤害。
        register(WeaponDef.builder(IZANAGI, WeaponType.SNIPER_RIFLE, ElementKind.KINETIC)
                .magazine(4)
                .reloadTicks(50)
                .damage(18.0F)
                .fireIntervalTicks(20)
                .range(64.0F)
                .spread(0.35F, 0.05F)
                .recoil(0.28F)
                .critMultiplier(1.8F)
                .chargeable(40, 3, 3.5F)
                .perk("honed_edge")
                .build());

        // 7. 山巅：单发榴弹，爆炸带自推力，可以「火箭跳」。
        register(WeaponDef.builder(MOUNTAINTOP, WeaponType.GRENADE_LAUNCHER, ElementKind.KINETIC)
                .magazine(1)
                .reloadTicks(45)
                .damage(16.0F)
                .fireIntervalTicks(25)
                .range(44.0F)
                .spread(0.8F, 0.25F)
                .recoil(0.22F)
                .critMultiplier(1.15F)
                .perk("micro_missile")
                .build());

        // 8. 引力子长矛：击杀生成虚空奇点，吸住并持续伤害周围的敌人。
        register(WeaponDef.builder(GRAVITON_LANCE, WeaponType.PULSE_RIFLE, ElementKind.VOID)
                .magazine(30)
                .reloadTicks(44)
                .damage(6.0F)
                .fireIntervalTicks(6)
                .range(38.0F)
                .spread(1.0F, 0.20F)
                .recoil(0.12F)
                .critMultiplier(1.4F)
                .perk("black_hole")
                .build());

        ALL = List.copyOf(BY_ID.values());
    }

    private WeaponCatalog() {
    }

    private static void register(WeaponDef def) {
        BY_ID.put(def.id, def);
    }

    public static Optional<WeaponDef> byId(String id) {
        return Optional.ofNullable(BY_ID.get(id));
    }

    public static WeaponDef get(String id) {
        WeaponDef def = BY_ID.get(id);
        if (def == null) {
            throw new IllegalArgumentException("未知武器 id: " + id);
        }
        return def;
    }
}
