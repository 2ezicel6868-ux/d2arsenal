package dev.destinyarsenal.core;

/**
 * 单名玩家的枪械运行时状态（纯 Java，可单元测试）。
 * <p>刻意不做持久化：换弹进度、层数、连击这些都属于「瞬时战斗状态」，
 * 掉线/切枪后重置是合理的。</p>
 */
public final class GunRuntime {

    private String weaponId = "";
    private long lastShotTick = Long.MIN_VALUE / 2;
    private boolean reloading = false;
    private long reloadEndTick = 0L;
    private int reloadDuration = 0;
    /** 「亡命」/「雷暴」之类的连击层数。 */
    private int stacks = 0;
    /** 换弹后的强化一发（旭日）。 */
    private boolean primed = false;
    /** 正在蓄力时的起始 tick，-1 表示未蓄力。 */
    private long chargeStartTick = -1L;

    /** 切换武器时清空与具体武器绑定的状态。 */
    public void select(String id) {
        if (!this.weaponId.equals(id)) {
            this.weaponId = id;
            this.reloading = false;
            this.reloadEndTick = 0L;
            this.reloadDuration = 0;
            this.stacks = 0;
            this.primed = false;
            this.chargeStartTick = -1L;
        }
    }

    public String weaponId() {
        return this.weaponId;
    }

    public boolean canShoot(long now, int fireIntervalTicks) {
        if (this.reloading) {
            return false;
        }
        return now - this.lastShotTick >= fireIntervalTicks;
    }

    public void markShot(long now) {
        this.lastShotTick = now;
        this.primed = false;
    }

    public long lastShotTick() {
        return this.lastShotTick;
    }

    public boolean isReloading() {
        return this.reloading;
    }

    public boolean isReloading(long now) {
        return this.reloading && now < this.reloadEndTick;
    }

    public long reloadEndTick() {
        return this.reloadEndTick;
    }

    public int reloadDuration() {
        return this.reloadDuration;
    }

    /** @return 是否成功开始换弹 */
    public boolean startReload(long now, int durationTicks) {
        if (this.reloading) {
            return false;
        }
        this.reloading = true;
        this.reloadDuration = durationTicks;
        this.reloadEndTick = now + durationTicks;
        return true;
    }

    /** 换弹完成，返回是否真的完成了。 */
    public boolean finishReload(long now) {
        if (!this.reloading || now < this.reloadEndTick) {
            return false;
        }
        this.reloading = false;
        this.stacks = 0;
        this.primed = true;
        return true;
    }

    public void cancelReload() {
        this.reloading = false;
        this.reloadEndTick = 0L;
        this.reloadDuration = 0;
    }

    /** 换弹进度 0..1，用于显示。 */
    public float reloadProgress(long now) {
        if (!this.reloading || this.reloadDuration <= 0) {
            return 0.0F;
        }
        long remaining = Math.max(0L, this.reloadEndTick - now);
        return 1.0F - (float) remaining / (float) this.reloadDuration;
    }

    public int stacks() {
        return this.stacks;
    }

    public void setStacks(int value) {
        this.stacks = Math.max(0, value);
    }

    public int addStack(int max) {
        this.stacks = Math.min(max, this.stacks + 1);
        return this.stacks;
    }

    public void resetStacks() {
        this.stacks = 0;
    }

    public boolean isPrimed() {
        return this.primed;
    }

    public void clearPrimed() {
        this.primed = false;
    }

    public long chargeStartTick() {
        return this.chargeStartTick;
    }

    public void beginCharge(long now) {
        this.chargeStartTick = now;
    }

    public int chargeTicks(long now) {
        if (this.chargeStartTick < 0) {
            return 0;
        }
        return (int) Math.max(0L, now - this.chargeStartTick);
    }

    public void endCharge() {
        this.chargeStartTick = -1L;
    }
}
