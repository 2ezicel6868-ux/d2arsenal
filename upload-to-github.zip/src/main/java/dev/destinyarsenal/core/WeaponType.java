package dev.destinyarsenal.core;

/** 武器种类（对应《命运 2》的框架分类）。 */
public enum WeaponType {
    HAND_CANNON("hand_cannon", 0.9F),
    AUTO_RIFLE("auto_rifle", 0.8F),
    PULSE_RIFLE("pulse_rifle", 0.7F),
    SUBMACHINE_GUN("smg", 0.8F),
    SNIPER_RIFLE("sniper", 1.0F),
    MACHINE_GUN("machine_gun", 0.75F),
    ROCKET_LAUNCHER("rocket_launcher", 1.0F),
    GRENADE_LAUNCHER("grenade_launcher", 1.0F);

    private final String key;
    /** 手感系数：影响后坐力与散布的缩放。 */
    private final float handling;

    WeaponType(String key, float handling) {
        this.key = key;
        this.handling = handling;
    }

    public String key() {
        return this.key;
    }

    public float handling() {
        return this.handling;
    }

    /** 语言文件键，例如 {@code weapon.destinyarsenal.type.hand_cannon}。 */
    public String translationKey() {
        return "weapon.destinyarsenal.type." + this.key;
    }
}
