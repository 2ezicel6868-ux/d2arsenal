package dev.destinyarsenal.core;

import java.util.Random;

/**
 * 散布（spread）计算：把「角色状态」翻译成实际的角度偏移。
 * <p>纯函数，方便写断言：潜行/静止应当更准，冲刺/滞空应当更散。</p>
 */
public final class Spread {

    private Spread() {
    }

    /**
     * 当前状态下应使用的散布角（度）。
     *
     * @param def 武器定义
     * @param sprinting 是否在冲刺
     * @param airborne 是否离地
     * @param sneaking 是否潜行
     */
    public static double effectiveSpread(WeaponDef def, boolean sprinting, boolean airborne, boolean sneaking) {
        double base;
        if (sneaking) {
            base = def.bracedSpread;
        } else if (sprinting) {
            base = def.hipSpread * 2.1D;
        } else if (airborne) {
            base = def.hipSpread * 1.7D;
        } else {
            base = def.hipSpread;
        }
        // 榴弹/火箭筒靠齐射覆盖，不做额外补偿
        return base * def.type.handling();
    }

    /**
     * 在 {@code look} 方向上加一个随机偏移。
     *
     * @param look 已归一化的视线方向
     * @param spreadDegrees 散布角（度），0 表示完全精准
     * @param rng 随机源（测试里传固定种子即可复现）
     */
    public static Vec3 jitter(Vec3 look, double spreadDegrees, Random rng) {
        if (spreadDegrees <= 1.0E-6D) {
            return look.normalize();
        }
        Vec3 forward = look.normalize();
        // 取一个与 forward 最不平行的坐标轴来构造正交基
        Vec3 helper = Math.abs(forward.y()) < 0.9D ? Vec3.UP : new Vec3(1.0D, 0.0D, 0.0D);
        Vec3 right = forward.cross(helper).normalize();
        Vec3 up = right.cross(forward).normalize();

        // 在单位圆盘内均匀取点（sqrt 保证面积均匀）
        double radius = Math.sqrt(rng.nextDouble());
        double theta = rng.nextDouble() * Math.PI * 2.0D;
        double offsetX = Math.cos(theta) * radius;
        double offsetY = Math.sin(theta) * radius;

        double tanMax = Math.tan(Math.toRadians(spreadDegrees));
        return forward
                .add(right.scale(offsetX * tanMax))
                .add(up.scale(offsetY * tanMax))
                .normalize();
    }
}
