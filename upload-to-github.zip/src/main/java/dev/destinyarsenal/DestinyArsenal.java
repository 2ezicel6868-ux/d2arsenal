package dev.destinyarsenal;

import dev.destinyarsenal.core.WeaponCatalog;
import dev.destinyarsenal.registry.ModItemGroup;
import dev.destinyarsenal.registry.ModItems;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLPaths;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * 《命运 2》军械库 · Forge 1.20.1 入口。
 *
 * <p>本 mod 内**自带一份 TaCZ 枪包**（{@code tacz_bundle/d2arsenal_gun_pack.zip}）。
 * 首次启动时会被释放到游戏目录的 {@code tacz/} 下，于是「只装一个 jar」就能同时得到
 * Java 版武器逻辑与 TaCZ 枪包内容。已存在则跳过，不会覆盖你手动改过的版本。</p>
 */
@Mod(DestinyArsenal.MOD_ID)
public class DestinyArsenal {

    public static final String MOD_ID = "destinyarsenal";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /** jar 内自带枪包的资源路径。 */
    private static final String BUNDLED_PACK = "/tacz_bundle/d2arsenal_gun_pack.zip";
    /** 释放到 tacz/ 下的文件名。 */
    private static final String BUNDLED_PACK_NAME = "d2arsenal_gun_pack.zip";

    public DestinyArsenal() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.register(modBus);
        ModItemGroup.register(modBus);

        MinecraftForge.EVENT_BUS.register(GunHandler.class);

        installBundledGunPack();

        LOGGER.info("命运 2 军械库已装填 {} 把异域武器。", WeaponCatalog.ALL.size());
    }

    /**
     * 把 jar 内自带的 TaCZ 枪包释放到 {@code <游戏目录>/tacz/}。
     * <p>放在构造函数里执行：此时资源管理器还没开始扫描枪包，来得及。</p>
     */
    private static void installBundledGunPack() {
        Path taczDir = FMLPaths.GAMEDIR.get().resolve("tacz");
        Path target = taczDir.resolve(BUNDLED_PACK_NAME);

        try (InputStream bundled = DestinyArsenal.class.getResourceAsStream(BUNDLED_PACK)) {
            if (bundled == null) {
                LOGGER.warn("jar 内没有找到自带枪包 {}，跳过释放。", BUNDLED_PACK);
                return;
            }
            if (Files.exists(target)) {
                LOGGER.info("检测到已存在的 TaCZ 枪包，跳过释放：{}", target);
                return;
            }
            Files.createDirectories(taczDir);
            Files.copy(bundled, target);
            LOGGER.info("已释放 TaCZ 枪包：{}", target);
        } catch (IOException exception) {
            LOGGER.error("释放 TaCZ 枪包失败（不影响 Java 版武器），目标：{}", target, exception);
        }
    }
}
