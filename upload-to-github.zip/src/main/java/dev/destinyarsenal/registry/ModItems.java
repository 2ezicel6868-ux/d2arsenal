package dev.destinyarsenal.registry;

import dev.destinyarsenal.DestinyArsenal;
import dev.destinyarsenal.core.WeaponCatalog;
import dev.destinyarsenal.core.WeaponDef;
import dev.destinyarsenal.item.GunItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 物品注册（Forge 1.20.1）。
 * <p>弹匣容量直接用作物品耐久上限，于是「耐久条」天然就是弹药条。</p>
 */
public final class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, DestinyArsenal.MOD_ID);

    /** 注册顺序 = 创造模式物品栏顺序。 */
    public static final List<RegistryObject<GunItem>> ALL = new ArrayList<>();

    public static final RegistryObject<GunItem> GJALLARHORN = create(WeaponCatalog.GJALLARHORN);
    public static final RegistryObject<GunItem> LAST_WORD = create(WeaponCatalog.LAST_WORD);
    public static final RegistryObject<GunItem> FATEBRINGER = create(WeaponCatalog.FATEBRINGER);
    public static final RegistryObject<GunItem> THUNDERLORD = create(WeaponCatalog.THUNDERLORD);
    public static final RegistryObject<GunItem> SUNSHOT = create(WeaponCatalog.SUNSHOT);
    public static final RegistryObject<GunItem> IZANAGI = create(WeaponCatalog.IZANAGI);
    public static final RegistryObject<GunItem> MOUNTAINTOP = create(WeaponCatalog.MOUNTAINTOP);
    public static final RegistryObject<GunItem> GRAVITON_LANCE = create(WeaponCatalog.GRAVITON_LANCE);

    private ModItems() {
    }

    private static RegistryObject<GunItem> create(String id) {
        WeaponDef def = WeaponCatalog.get(id);
        RegistryObject<GunItem> item = ITEMS.register(id, () -> new GunItem(def,
                new Item.Properties()
                        .durability(def.magazine)
                        .rarity(Rarity.EPIC)));
        ALL.add(item);
        return item;
    }

    public static void register(IEventBus modEventBus) {
        ITEMS.register(modEventBus);
    }
}
