#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
资源与工程一致性校验（NeoForge 版，不启动 Minecraft 也能跑）。

检查内容：
  1. 所有 JSON 可解析；
  2. META-INF/neoforge.mods.toml 齐全、modId/版本与 gradle.properties 一致；
  3. 没有任何 Fabric 残留（fabric.mod.json / net.fabricmc 导入）；
  4. core 包保持「纯 Java」——不 import 任何 Minecraft / NeoForge 类；
  5. WeaponCatalog 里的每把枪，在「模型 / 贴图 / 语言 / 配方」四处都齐；
  6. 模型引用的贴图真实存在；贴图尺寸正确（物品 16x16，图标 128x128）；
  7. en_us 与 zh_cn 的键集合完全一致；
  8. Java 里出现的每个 Component.translatable("...") 的键，在语言文件里都有；
  9. 枚举里的类型 / 元素 / 特性都有对应语言键；
 10. 配方排版合法、材料符号都有定义、产物 id 是已注册的枪。

用法：
    python tools/validate.py
返回码 0 表示全部通过。
"""

from __future__ import annotations

import json
import os
import re
import sys

try:
    import tomllib  # Python 3.11+
except ImportError:  # pragma: no cover
    tomllib = None

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, "src", "main", "resources")
JAVA = os.path.join(ROOT, "src", "main", "java")
MODS_TOML = os.path.join(RES, "META-INF", "mods.toml")
BUNDLED_PACK = os.path.join(RES, "tacz_bundle", "d2arsenal_gun_pack.zip")
GRADLE_PROPS = os.path.join(ROOT, "gradle.properties")

MOD_ID = "destinyarsenal"
errors: list[str] = []
checked = 0


def fail(message: str) -> None:
    errors.append(message)


def ok() -> None:
    global checked
    checked += 1


def rel(path: str) -> str:
    return os.path.relpath(path, ROOT).replace("\\", "/")


def load_json(path: str):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            return json.load(handle)
    except Exception as exc:  # noqa: BLE001
        fail(f"JSON 解析失败: {rel(path)} -> {exc}")
        return None


def read(path: str) -> str:
    with open(path, "r", encoding="utf-8") as handle:
        return handle.read()


def gradle_properties() -> dict:
    props = {}
    if not os.path.isfile(GRADLE_PROPS):
        fail("缺少 gradle.properties")
        return props
    for line in read(GRADLE_PROPS).splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        props[key.strip()] = value.strip()
    return props


# ------------------------------------------------------------------ 1. JSON 全量
def check_all_json() -> dict:
    parsed = {}
    for base, _dirs, files in os.walk(RES):
        for name in files:
            if not name.endswith(".json"):
                continue
            path = os.path.join(base, name)
            data = load_json(path)
            if data is not None:
                parsed[rel(path)] = data
                ok()
    return parsed


# ------------------------------------------------------------------ 2. neoforge.mods.toml
def check_mods_toml(props: dict) -> None:
    if not os.path.isfile(MODS_TOML):
        fail("缺少 META-INF/neoforge.mods.toml")
        return
    ok()

    source = read(MODS_TOML)
    data = None
    if tomllib is not None:
        try:
            data = tomllib.loads(source)
            ok()
        except Exception as exc:  # noqa: BLE001
            fail(f"neoforge.mods.toml 语法错误: {exc}")
            return
    else:  # pragma: no cover - 兜底：只做关键字检查
        for key in ("modLoader", "loaderVersion", "license", "[[mods]]"):
            if key not in source:
                fail(f"neoforge.mods.toml 缺少 {key}")
            else:
                ok()
        return

    for key in ("modLoader", "loaderVersion", "license"):
        if key not in data:
            fail(f"neoforge.mods.toml 缺少顶层字段 {key}")
        else:
            ok()
    if data.get("modLoader") != "javafml":
        fail(f"modLoader 应为 javafml，实际 {data.get('modLoader')}")
    else:
        ok()

    mods = data.get("mods") or []
    if len(mods) != 1:
        fail(f"[[mods]] 应恰好 1 段，实际 {len(mods)}")
        return
    mod = mods[0]
    ok()

    if mod.get("modId") != MOD_ID:
        fail(f"modId 应为 {MOD_ID}，实际 {mod.get('modId')}")
    else:
        ok()

    expected_version = props.get("mod_version")
    if expected_version and mod.get("version") != expected_version:
        fail(f"mods.toml 版本 {mod.get('version')} 与 gradle.properties 的 {expected_version} 不一致")
    else:
        ok()

    for key in ("displayName", "description"):
        if not mod.get(key):
            fail(f"mods.toml 缺少 {key}")
        else:
            ok()

    logo = mod.get("logoFile")
    if logo and not os.path.isfile(os.path.join(RES, logo)):
        fail(f"mods.toml 的 logoFile 不存在: {logo}")
    else:
        ok()

    deps = data.get("dependencies", {}).get(MOD_ID, [])
    dep_ids = {dep.get("modId") for dep in deps}
    for required in ("forge", "minecraft"):
        if required not in dep_ids:
            fail(f"mods.toml 缺少对 {required} 的依赖声明")
        else:
            ok()
    if "tacz" not in dep_ids:
        fail("mods.toml 缺少对 tacz 的可选依赖声明（用于兼容性与加载顺序）")
    else:
        ok()
    tacz_dep = next((d for d in deps if d.get("modId") == "tacz"), {})
    if tacz_dep.get("mandatory") is not False:
        fail(f"tacz 依赖应为非强制（mandatory=false），实际 {tacz_dep.get('mandatory')}")
    else:
        ok()


# ------------------------------------------------------------------ 3. Fabric 残留
def check_loader_consistency() -> None:
    """工程必须是 Forge 1.20.1：不能残留 Fabric / NeoForge 的东西。"""
    if os.path.isfile(os.path.join(RES, "fabric.mod.json")):
        fail("仍存在 fabric.mod.json（本工程已改为 Forge）")
    else:
        ok()
    if os.path.isfile(os.path.join(RES, "META-INF", "neoforge.mods.toml")):
        fail("仍存在 META-INF/neoforge.mods.toml（Forge 1.20.1 用 mods.toml）")
    else:
        ok()
    if not os.path.isfile(MODS_TOML):
        fail("缺少 META-INF/mods.toml")
    else:
        ok()

    offenders = []
    for base, _dirs, files in os.walk(JAVA):
        for name in files:
            if not name.endswith(".java"):
                continue
            path = os.path.join(base, name)
            source = read(path)
            if "net.fabricmc" in source or "net.neoforged" in source:
                offenders.append(rel(path))
    if offenders:
        fail(f"这些文件仍引用 Fabric/NeoForge: {offenders}")
    else:
        ok()

    build = read(os.path.join(ROOT, "build.gradle"))
    if "net.minecraftforge.gradle" not in build:
        fail("build.gradle 没有使用 net.minecraftforge.gradle（ForgeGradle）插件")
    else:
        ok()
    if re.search(r"net\.neoforged|fabric-?loom|net\.fabricmc", build, re.I):
        fail("build.gradle 里仍有 NeoForge/Fabric 构建配置残留")
    else:
        ok()


def check_bundled_pack() -> None:
    """jar 内自带的 TaCZ 枪包必须存在且结构正确（这是「一个 jar 搞定」的关键）。"""
    import zipfile

    if not os.path.isfile(BUNDLED_PACK):
        fail("缺少内嵌枪包 src/main/resources/tacz_bundle/d2arsenal_gun_pack.zip")
        return
    ok()
    try:
        with zipfile.ZipFile(BUNDLED_PACK) as archive:
            names = archive.namelist()
            if "gunpack.meta.json" not in names:
                fail("内嵌枪包根目录缺 gunpack.meta.json")
            else:
                ok()
            meta = archive.read("gunpack.meta.json").decode("utf-8", "replace")
            if '"d2arsenal"' not in meta:
                fail("内嵌枪包的 namespace 不是 d2arsenal")
            else:
                ok()
            guns = [n for n in names if re.search(r"/index/guns/[^/]+\.json$", n)]
            if len(guns) != 8:
                fail(f"内嵌枪包应含 8 把枪，实际 {len(guns)}")
            else:
                ok()
    except zipfile.BadZipFile:
        fail("内嵌枪包不是合法 zip")


# ------------------------------------------------------------------ 4. core 纯度
def check_core_purity() -> None:
    core_dir = os.path.join(JAVA, "dev", "destinyarsenal", "core")
    offenders = []
    for name in os.listdir(core_dir):
        if not name.endswith(".java"):
            continue
        source = read(os.path.join(core_dir, name))
        if re.search(r"^\s*import\s+(net\.minecraft|net\.neoforged)", source, re.M):
            offenders.append(name)
    if offenders:
        fail(f"core 包必须保持纯 Java，但这些文件引用了 Minecraft: {offenders}")
    else:
        ok()


# ------------------------------------------------------------------ 5/6. 武器 id 与资源
def catalog_entries() -> list[dict]:
    """从 WeaponCatalog.java 抽取每把枪的 id / 类型 / 元素 / 特性。"""
    source = read(os.path.join(JAVA, "dev", "destinyarsenal", "core", "WeaponCatalog.java"))
    constants = dict(re.findall(r'String\s+(\w+)\s*=\s*"([^"]+)"', source))
    entries = []
    pattern = re.compile(
        r"WeaponDef\.builder\(\s*(\w+)\s*,\s*WeaponType\.(\w+)\s*,\s*ElementKind\.(\w+)\s*\)"
        r"(.*?)\.build\(\)",
        re.S,
    )
    for const, wtype, element, body in pattern.findall(source):
        weapon_id = constants.get(const)
        if weapon_id is None:
            fail(f"WeaponCatalog 中无法解析常量 {const}")
            continue
        perk_match = re.search(r'\.perk\("([^"]+)"\)', body)
        entries.append({
            "id": weapon_id,
            "type": wtype.lower(),
            "element": element.lower(),
            "perk": perk_match.group(1) if perk_match else None,
        })
    return entries


def png_size(path: str) -> tuple:
    """不依赖 Pillow 读取 PNG 尺寸（IHDR 前 24 字节）。"""
    with open(path, "rb") as handle:
        head = handle.read(24)
    if len(head) < 24 or head[1:4] != b"PNG":
        return (-1, -1)
    return (int.from_bytes(head[16:20], "big"), int.from_bytes(head[20:24], "big"))


def check_recipe_shape(weapon_id: str, recipe: dict) -> None:
    if recipe.get("type") != "minecraft:crafting_shaped":
        fail(f"[{weapon_id}] 配方类型应为 crafting_shaped")
        return
    pattern = recipe.get("pattern", [])
    if len(pattern) != 3 or any(len(row) != 3 for row in pattern):
        fail(f"[{weapon_id}] 配方应为 3x3，实际 {pattern}")
        return
    ok()

    symbols = set("".join(pattern).replace(" ", ""))
    key = recipe.get("key", {})
    if not symbols.issubset(set(key.keys())):
        fail(f"[{weapon_id}] 配方图案用了未定义的材料符号: {symbols - set(key)}")
    else:
        ok()

    for symbol, definition in key.items():
        item = definition.get("item", "")
        if not item.startswith("minecraft:"):
            fail(f"[{weapon_id}] 材料 {symbol} 应指向 minecraft: 命名空间，实际 {item}")
        else:
            ok()

    result = recipe.get("result", {})
    if result.get("id") != f"{MOD_ID}:{weapon_id}":
        fail(f"[{weapon_id}] 配方产物应为 {MOD_ID}:{weapon_id}，实际 {result.get('id')}")
    else:
        ok()


def check_weapon_resources(entries: list[dict], parsed: dict) -> dict:
    if len(entries) != 8:
        fail(f"WeaponCatalog 里应有 8 把武器，解析到 {len(entries)} 把")
    else:
        ok()

    for entry in entries:
        weapon_id = entry["id"]

        model_rel = f"src/main/resources/assets/{MOD_ID}/models/item/{weapon_id}.json"
        model = parsed.get(model_rel)
        if model is None:
            fail(f"[{weapon_id}] 缺少物品模型")
        else:
            ok()
            layer = model.get("textures", {}).get("layer0", "")
            if layer != f"{MOD_ID}:item/{weapon_id}":
                fail(f"[{weapon_id}] 模型 layer0 错误: {layer}")
            else:
                ok()

        texture_path = os.path.join(RES, "assets", MOD_ID, "textures", "item", f"{weapon_id}.png")
        if not os.path.isfile(texture_path):
            fail(f"[{weapon_id}] 缺少贴图")
        else:
            ok()
            size = png_size(texture_path)
            if size != (16, 16):
                fail(f"[{weapon_id}] 贴图尺寸应为 16x16，实际 {size}")
            else:
                ok()

        recipe_rel = f"src/main/resources/data/{MOD_ID}/recipe/{weapon_id}.json"
        recipe = parsed.get(recipe_rel)
        if recipe is None:
            fail(f"[{weapon_id}] 缺少配方")
        else:
            ok()
            check_recipe_shape(weapon_id, recipe)

    icon = os.path.join(RES, "assets", MOD_ID, "icon.png")
    if os.path.isfile(icon):
        size = png_size(icon)
        if size != (128, 128):
            fail(f"icon.png 尺寸应为 128x128，实际 {size}")
        else:
            ok()

    return {
        "en_us": parsed.get(f"src/main/resources/assets/{MOD_ID}/lang/en_us.json", {}),
        "zh_cn": parsed.get(f"src/main/resources/assets/{MOD_ID}/lang/zh_cn.json", {}),
    }


# ------------------------------------------------------------------ 7. 语言文件
def check_lang(entries: list[dict], langs: dict) -> dict:
    en = langs.get("en_us", {})
    zh = langs.get("zh_cn", {})
    if set(en) != set(zh):
        only_en = sorted(set(en) - set(zh))
        only_zh = sorted(set(zh) - set(en))
        fail(f"en_us 与 zh_cn 键不一致；仅英文 {only_en[:5]}，仅中文 {only_zh[:5]}")
    else:
        ok()

    for locale, table in (("en_us", en), ("zh_cn", zh)):
        for key, value in table.items():
            if not isinstance(value, str) or not value.strip():
                fail(f"{locale} 的 {key} 为空")
        ok()

    for entry in entries:
        for locale, table in (("en_us", en), ("zh_cn", zh)):
            key = f"item.{MOD_ID}.{entry['id']}"
            if key not in table:
                fail(f"[{entry['id']}] {locale} 缺少名称键 {key}")
            else:
                ok()
    return langs


# ------------------------------------------------------------------ 8/9. Java 键 + 动态键
def check_java_lang_keys(langs: dict) -> None:
    used: dict[str, str] = {}
    for base, _dirs, files in os.walk(JAVA):
        for name in files:
            if not name.endswith(".java"):
                continue
            path = os.path.join(base, name)
            source = read(path)
            patterns = (
                r'translatable\(\s*"([^"]+)"',   # Mojang: Component.translatable
                r'literal\(\s*"([^"]+)"',        # 仅用于统计，不校验
            )
            for key in re.findall(patterns[0], source):
                used.setdefault(key, os.path.basename(path))

    for key, origin in sorted(used.items()):
        for locale, table in langs.items():
            if key not in table:
                fail(f"{locale} 缺少 Java 用到的键 {key}（来自 {origin}）")
            else:
                ok()
    print(f"  Java 中直接引用的语言键: {len(used)} 个")


def enum_keys(file_name: str) -> list[str]:
    path = os.path.join(JAVA, "dev", "destinyarsenal", "core", file_name)
    if not os.path.isfile(path):
        fail(f"找不到枚举文件 {file_name}")
        return []
    return re.findall(r'^\s*[A-Z_0-9]+\(\s*"([^"]+)"', read(path), re.M)


def check_dynamic_keys(entries: list[dict], langs: dict) -> None:
    type_ids = set(enum_keys("WeaponType.java"))
    element_ids = set(enum_keys("ElementKind.java"))
    perk_ids = {entry["perk"] for entry in entries if entry["perk"]}

    if not type_ids:
        fail("未从 WeaponType.java 解析出任何类型 key")
    if not element_ids:
        fail("未从 ElementKind.java 解析出任何元素 key")

    for locale, table in langs.items():
        for type_id in type_ids:
            key = f"weapon.destinyarsenal.type.{type_id}"
            if key not in table:
                fail(f"{locale} 缺少类型键 {key}")
            else:
                ok()
        for element_id in element_ids:
            key = f"weapon.destinyarsenal.element.{element_id}"
            if key not in table:
                fail(f"{locale} 缺少元素键 {key}")
            else:
                ok()
        for perk_id in perk_ids:
            for suffix in ("name", "desc"):
                key = f"weapon.destinyarsenal.perk.{perk_id}.{suffix}"
                if key not in table:
                    fail(f"{locale} 缺少特性键 {key}")
                else:
                    ok()
        if "itemGroup.destinyarsenal.arsenal" not in table:
            fail(f"{locale} 缺少创造模式页签键 itemGroup.destinyarsenal.arsenal")
        else:
            ok()


# ------------------------------------------------------------------ 10. 注册表
def check_registration(entries: list[dict]) -> None:
    source = read(os.path.join(JAVA, "dev", "destinyarsenal", "registry", "ModItems.java"))
    registered = re.findall(
        r"public static final (?:RegistryObject<GunItem>|DeferredItem<GunItem>|GunItem) \w+"
        r" = create\(WeaponCatalog\.(\w+)\);",
        source,
    )
    catalog_source = read(os.path.join(JAVA, "dev", "destinyarsenal", "core", "WeaponCatalog.java"))
    constants = dict(re.findall(r'String\s+(\w+)\s*=\s*"([^"]+)"', catalog_source))

    registered_ids = []
    for const in registered:
        if const in constants:
            registered_ids.append(constants[const])
        else:
            fail(f"ModItems 引用了未知常量 {const}")

    catalog_ids = [entry["id"] for entry in entries]
    if sorted(registered_ids) != sorted(catalog_ids):
        fail(f"ModItems 注册 {sorted(registered_ids)} 与武器表 {sorted(catalog_ids)} 不一致")
    else:
        ok()
    if len(set(registered_ids)) != len(registered_ids):
        fail("ModItems 中存在重复注册")
    else:
        ok()


def check_pack_mcmeta() -> None:
    """Forge 需要 jar 里的 pack.mcmeta 才能把 assets/ 当成资源包加载。"""
    path = os.path.join(RES, "pack.mcmeta")
    if not os.path.isfile(path):
        fail("缺少 src/main/resources/pack.mcmeta（否则贴图/语言不会加载）")
        return
    ok()
    data = load_json(path)
    if data is None:
        return
    pack = data.get("pack") or {}
    for key in ("description", "pack_format"):
        if key not in pack:
            fail(f"pack.mcmeta 缺少 pack.{key}")
        else:
            ok()
    if pack.get("pack_format") != 15:
        fail(f"1.20.1 的 pack_format 应为 15，实际 {pack.get('pack_format')}")
    else:
        ok()


def main() -> int:
    print("开始校验资源与工程一致性（Forge 1.20.1）…")
    props = gradle_properties()
    parsed = check_all_json()
    check_mods_toml(props)
    check_loader_consistency()
    check_bundled_pack()
    check_pack_mcmeta()
    check_core_purity()
    entries = catalog_entries()
    langs = check_weapon_resources(entries, parsed)
    langs = check_lang(entries, langs or {})
    check_java_lang_keys(langs)
    check_dynamic_keys(entries, langs)
    check_registration(entries)

    print()
    if errors:
        print(f"校验失败：{len(errors)} 个问题")
        for message in errors:
            print("  -", message)
        return 1
    print(f"校验通过：{checked} 项检查全部 OK")
    return 0


if __name__ == "__main__":
    sys.exit(main())
