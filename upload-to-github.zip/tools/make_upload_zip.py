#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成「可以直接用 GitHub 网页上传」的单个 zip —— 内容平铺在压缩包根目录。

背景：GitHub 网页上传一次最多 100 个文件，本工程有 160+ 个，
      所以只上传这一个 zip，再由 CI（ci/bootstrap-build.yml）自己解压。

用法：python tools/make_upload_zip.py
输出：dist/upload-to-github.zip
"""

from __future__ import annotations

import os
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "dist", "upload-to-github.zip")

# 这些是构建产物 / 缓存，不进仓库
EXCLUDE_DIRS = {"build", "dist", ".git", "__pycache__", "run", "out", ".gradle"}
# 上传包自身不能被打进上传包里（否则仓库里会出现一份过期的旧压缩包）
EXCLUDE_FILES = {".DS_Store", "Thumbs.db", "upload-to-github.zip"}
FIXED_TIME = (2026, 11, 14, 0, 0, 0)


def collect() -> list[tuple[str, str]]:
    entries: list[tuple[str, str]] = []
    for base, dirs, files in os.walk(ROOT):
        dirs[:] = sorted(d for d in dirs if d not in EXCLUDE_DIRS)
        for name in sorted(files):
            if name in EXCLUDE_FILES or name.endswith(".pyc"):
                continue
            full = os.path.join(base, name)
            arcname = os.path.relpath(full, ROOT).replace(os.sep, "/")
            if arcname.startswith("./"):
                arcname = arcname[2:]
            entries.append((full, arcname))
    return entries


def main() -> int:
    entries = collect()
    if not entries:
        print("没有可打包的文件")
        return 1

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with zipfile.ZipFile(OUT, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for full, arcname in entries:
            info = zipfile.ZipInfo(arcname, date_time=FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            with open(full, "rb") as handle:
                archive.writestr(info, handle.read())

    with zipfile.ZipFile(OUT) as archive:
        names = archive.namelist()
        required = ["build.gradle", "settings.gradle", "gradle.properties",
                    ".github/workflows/build.yml", "ci/bootstrap-build.yml",
                    "src/main/resources/META-INF/mods.toml",
                    "src/main/resources/tacz_bundle/d2arsenal_gun_pack.zip"]
        missing = [item for item in required if item not in names]
        flat = not any(name.startswith("destiny2-arsenal/") for name in names)

    print(f"已生成: {OUT}")
    print(f"  条目数: {len(names)}")
    print(f"  根目录平铺（无外层目录）: {flat}")
    print(f"  关键文件缺失: {missing if missing else '无'}")
    print(f"  体积: {round(os.path.getsize(OUT) / 1024, 1)} KB")

    if missing or not flat:
        print("压缩包结构不符合要求")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
