#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成资源侧的 JSON：物品模型、合成配方、语言文件（en_us / zh_cn）。

之所以用脚本生成：这 8 把枪的 id 在「模型 / 配方 / 语言」三处必须完全一致，
手写容易漏。改武器只需要改下面的表，然后重跑本脚本。

用法：
    python tools/gen_json_assets.py
"""

from __future__ import annotations

import json
import os

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS = os.path.join(ROOT, "src", "main", "resources", "assets", "destinyarsenal")
DATA = os.path.join(ROOT, "src", "main", "resources", "data", "destinyarsenal")

MOD_ID = "destinyarsenal"

# id, 英文名, 中文名, 类型, 元素, 特性
WEAPONS = [
    ("gjallarhorn", "Gjallarhorn", "狼嚎", "rocket_launcher", "solar", "wolfpack"),
    ("last_word", "The Last Word", "最后的话语", "hand_cannon", "kinetic", "desperado"),
    ("fatebringer", "Fatebringer", "命运终结者", "hand_cannon", "kinetic", "firefly"),
    ("thunderlord", "Thunderlord", "雷神", "machine_gun", "arc", "lightning_rounds"),
    ("sunshot", "Sunshot", "旭日", "hand_cannon", "solar", "sunblast"),
    ("izanagis_burden", "Izanagi's Burden", "伊邪那岐的重担", "sniper", "kinetic", "honed_edge"),
    ("mountaintop", "Mountaintop", "山巅", "grenade_launcher", "kinetic", "micro_missile"),
    ("graviton_lance", "Graviton Lance", "引力子长矛", "pulse_rifle", "void", "black_hole"),
]

TYPES = {
    "hand_cannon": ("Hand Cannon", "手炮"),
    "auto_rifle": ("Auto Rifle", "自动步枪"),
    "pulse_rifle": ("Pulse Rifle", "脉冲步枪"),
    "smg": ("Submachine Gun", "冲锋枪"),
    "sniper": ("Sniper Rifle", "狙击步枪"),
    "machine_gun": ("Machine Gun", "机枪"),
    "rocket_launcher": ("Rocket Launcher", "火箭发射器"),
    "grenade_launcher": ("Grenade Launcher", "榴弹发射器"),
}

ELEMENTS = {
    "kinetic": ("Kinetic", "动能"),
    "solar": ("Solar", "烈日"),
    "arc": ("Arc", "电弧"),
    "void": ("Void", "虚空"),
    "stasis": ("Stasis", "冰影"),
}

PERKS = {
    "wolfpack": (
        "Wolfpack Rounds",
        "On hit, scatter 6 homing rounds that chain-explode the area.",
        "狼群弹",
        "命中后撒出 6 枚追踪弹，对周围区域造成连锁爆炸。",
    ),
    "desperado": (
        "Desperado",
        "Each hit grants a stack: +6% damage, up to 5 stacks. Reloading clears them.",
        "亡命之徒",
        "每次命中叠加一层「亡命」，每层 +6% 伤害（最多 5 层），换弹后清空。",
    ),
    "firefly": (
        "Firefly",
        "Precision kills detonate the target, damaging nearby enemies.",
        "萤火",
        "精准命中并击杀目标时，引爆其躯体并波及周围敌人。",
    ),
    "lightning_rounds": (
        "Lightning Rounds",
        "Every 3 consecutive hits calls down a small thunderstorm.",
        "闪电弹",
        "每连续命中 3 次召唤一次雷暴，造成范围电弧伤害。",
    ),
    "sunblast": (
        "Sunblast",
        "Hits cause a small solar blast and 4s of burning; first shot after reload deals +25%.",
        "日爆",
        "命中附带小型太阳爆炸与 4 秒灼烧；换弹后的第一枪伤害提升 25%。",
    ),
    "honed_edge": (
        "Honed Edge",
        "Charge for 2s to combine 4 rounds into one shot dealing 3.5x damage.",
        "磨砺之刃",
        "蓄力 2 秒可将弹匣中的 4 发弹药合成 1 发，造成 3.5 倍伤害。",
    ),
    "micro_missile": (
        "Micro-Missile",
        "Impact detonates violently; the recoil alone can launch you skyward.",
        "微型导弹",
        "命中点剧烈爆炸，后坐力强大到能把自己送上天。",
    ),
    "black_hole": (
        "Black Hole",
        "Kills leave a void singularity that drags in and shreds nearby targets.",
        "黑洞",
        "击杀后留下虚空奇点，吸附并持续撕裂周围目标。",
    ),
}

# id -> (配方排版, 材料表)  材料名 -> minecraft:xxx
INGREDIENTS = {
    "iron": "iron_ingot",
    "gold": "gold_ingot",
    "gunpowder": "gunpowder",
    "blaze_powder": "blaze_powder",
    "blaze_rod": "blaze_rod",
    "diamond": "diamond",
    "emerald": "emerald",
    "copper": "copper_ingot",
    "fire_charge": "fire_charge",
    "spectral_arrow": "spectral_arrow",
    "amethyst": "amethyst_shard",
    "tnt": "tnt",
    "ender_pearl": "ender_pearl",
    "ender_eye": "ender_eye",
    "netherite": "netherite_ingot",
}

RECIPES = {
    "gjallarhorn": (
        ["GFG", "INI", "GFG"],
        {"G": "gunpowder", "F": "blaze_powder", "I": "iron", "N": "netherite"},
    ),
    "last_word": (
        ["IGI", "GDG", "IGI"],
        {"I": "iron", "G": "gunpowder", "D": "diamond"},
    ),
    "fatebringer": (
        ["IGI", "GEG", "IGI"],
        {"I": "iron", "G": "gunpowder", "E": "emerald"},
    ),
    "thunderlord": (
        ["ICI", "GCG", "ICI"],
        {"I": "iron", "C": "copper", "G": "gunpowder"},
    ),
    "sunshot": (
        ["IFI", "GBG", "IFI"],
        {"I": "iron", "F": "fire_charge", "B": "blaze_rod", "G": "gunpowder"},
    ),
    "izanagis_burden": (
        ["ISI", "GAG", "ISI"],
        {"I": "iron", "S": "spectral_arrow", "A": "amethyst", "G": "gunpowder"},
    ),
    "mountaintop": (
        ["ITI", "GTG", "ITI"],
        {"I": "iron", "T": "tnt", "G": "gunpowder"},
    ),
    "graviton_lance": (
        ["IPI", "GEG", "IPI"],
        {"I": "iron", "P": "ender_pearl", "E": "ender_eye", "G": "gunpowder"},
    ),
}

STATIC_LANG = {
    "en_us": {
        "itemGroup.destinyarsenal.arsenal": "Destiny 2 Arsenal",
        "tooltip.destinyarsenal.stats": "Damage %s · Magazine %s",
        "tooltip.destinyarsenal.perk": "Perk: %s",
        "tooltip.destinyarsenal.ammo": "Ammo %s / %s",
        "tooltip.destinyarsenal.charge": "Hold %s s to forge an Honed Edge round",
        "message.destinyarsenal.reloading": "Reloading…",
        "message.destinyarsenal.reloaded": "Magazine loaded",
        "message.destinyarsenal.reload_full": "Magazine already full",
        "message.destinyarsenal.rocket_jump": "Rocket jump!",
    },
    "zh_cn": {
        "itemGroup.destinyarsenal.arsenal": "天命军械库",
        "tooltip.destinyarsenal.stats": "伤害 %s · 弹匣 %s",
        "tooltip.destinyarsenal.perk": "特性：%s",
        "tooltip.destinyarsenal.ammo": "弹药 %s / %s",
        "tooltip.destinyarsenal.charge": "按住 %s 秒可合成「荣耀之弹」",
        "message.destinyarsenal.reloading": "换弹中…",
        "message.destinyarsenal.reloaded": "弹药已装满",
        "message.destinyarsenal.reload_full": "弹匣已经是满的",
        "message.destinyarsenal.rocket_jump": "火箭跳！",
    },
}


def build_lang(locale: str) -> dict:
    keys = {}
    idx = 0 if locale == "en_us" else 1

    for perk_id, perk in PERKS.items():
        keys[f"weapon.destinyarsenal.perk.{perk_id}.name"] = perk[idx]
        keys[f"weapon.destinyarsenal.perk.{perk_id}.desc"] = perk[idx + 2]

    for type_id, names in TYPES.items():
        keys[f"weapon.destinyarsenal.type.{type_id}"] = names[idx]

    for element_id, names in ELEMENTS.items():
        keys[f"weapon.destinyarsenal.element.{element_id}"] = names[idx]

    for weapon_id, english, chinese, _type, _element, _perk in WEAPONS:
        keys[f"item.{MOD_ID}.{weapon_id}"] = english if locale == "en_us" else chinese

    keys.update(STATIC_LANG[locale])
    return dict(sorted(keys.items()))


def write_json(path: str, payload) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2)
        handle.write("\n")


def main() -> None:
    # 1. 物品模型
    for weapon_id, *_ in WEAPONS:
        write_json(
            os.path.join(ASSETS, "models", "item", f"{weapon_id}.json"),
            {
                "parent": "minecraft:item/handheld",
                "textures": {"layer0": f"{MOD_ID}:item/{weapon_id}"},
            },
        )

    # 2. 语言文件
    for locale in ("en_us", "zh_cn"):
        write_json(os.path.join(ASSETS, "lang", f"{locale}.json"), build_lang(locale))

    # 3. 合成配方
    for weapon_id, (pattern, key) in RECIPES.items():
        write_json(
            os.path.join(DATA, "recipe", f"{weapon_id}.json"),
            {
                "type": "minecraft:crafting_shaped",
                "category": "equipment",
                "pattern": pattern,
                "key": {
                    symbol: {"item": f"minecraft:{INGREDIENTS[material]}"}
                    for symbol, material in sorted(key.items())
                },
                "result": {"id": f"{MOD_ID}:{weapon_id}", "count": 1},
            },
        )

    print(f"生成完成：{len(WEAPONS)} 个模型 / 2 个语言文件 / {len(RECIPES)} 个配方")


if __name__ == "__main__":
    main()
